package com.dewaara.moviehub.adapters;

import android.widget.ImageView;

import com.dewaara.moviehub.models.Movie;

public interface MovieItemClickListener {


    void onMovieClick(Movie movie, ImageView movieImageView);


}
